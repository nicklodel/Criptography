function gen = generate(g,p)
tic
if g > p || floor(g) ~= g || floor(p) ~= p %%Check de si g es candidato
error('Argumentos no válidos');
end
gen = g;
pFactors = uint64(factor(p-1));

for i=1:length(pFactors)
    potencia = uint64(((p-1)/pFactors(i)));
    value = uint64(g^potencia);
    valuemod = uint64(mod(value,p));
    if valuemod == 1
    gen = 0;    
    break;
    end
end

time = toc;
fprintf('Han pasado %f segundos\n',time);
end